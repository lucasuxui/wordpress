<?php
  // phpcs:ignoreFile Internal.NoCodeFound
?>
<div id="font-awesome-admin">
</div>
